// 🧚‍♂️ ＰＡＮＤＡ-ＭＤ ƧΣƬƬIПG.JƧ 😚💋

const ownerNumber = require('./Owner/owner'); // 🔗 Example: ['923123456789']

const config = {
  // 👑 Owner Info
  ownerNumber,                          // 🔹 Array of Owner Numbers
  ownerName: '𝐄ꜱʜᴀɴ 𝐏ᴇʀᴇʀᴀ             // 🔹 Displayed in Greetings
  botName: 'ＰＡＮＤＡ-ＭＤ',           // 🔹 Bot Display Name
  signature: '> © Pᴀɴᴅᴀ Hᴏʟᴅɪɴɢꜱ (  Pᴠᴛ )  Lᴛᴅ',               // 🔹 Footer on Bot Replies
  TikTok: 'https://www.tiktok.com/@eshuu.korea', // 🔹 Optional YouTube

  // ⚙️ Feature Toggles
  autoTyping: false,        // ⌨️ Fake Typing
  autoReact: false,         // 💖 Auto Emoji Reaction
  autoStatusView: false,    // 👁️ Auto-View Status
  public: true,             // 🌍 Public or Private Mode
  antiLink: false,          // 🚫 Delete Links in Groups
  antiBug: false,           // 🛡️ Prevent Malicious Crashes
  greetings: true,          // 🙋 Welcome/Farewell Messages
  readmore: false,          // 📜 Readmore in Long Replies
  ANTIDELETE: true          // 🗑️ Anti-Delete Messages
};

// ✅ Register owner(s) globally in WhatsApp JID format
global.owner = (
  Array.isArray(ownerNumber) ? ownerNumber : [94710489158]
).map(num => num.replace(/\D/g, '') + '@s.whatsapp.net');

// ⚙️ Export Settings Loader
function loadSettings() {
  return config;
}

module.exports = { loadSettings };